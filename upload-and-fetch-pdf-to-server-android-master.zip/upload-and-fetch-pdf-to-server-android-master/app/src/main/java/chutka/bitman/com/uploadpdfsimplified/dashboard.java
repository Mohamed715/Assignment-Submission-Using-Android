package chutka.bitman.com.uploadpdfsimplified;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class dashboard  extends AppCompatActivity {

    private Button buttonReg, buttonAdmin, buttonViewMark, buttonAssReg;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        buttonReg = (Button) findViewById(R.id.buttonReg);

        buttonAdmin = (Button) findViewById(R.id.buttonAdmin);

        buttonReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registration();
            }
        });

        buttonAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                admin();
            }
        });

        buttonViewMark = (Button) findViewById(R.id.buttonViewMark);

        buttonViewMark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewMarks();
            }
        });



    }

    public void viewMarks(){
        Intent intent = new Intent(this, view_assignment_mark1.class);
        startActivity(intent);

    }

    public void registration(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

    public void admin(){
        Intent intent = new Intent(this, Login_Activity.class);
        startActivity(intent);

    }


}
