package chutka.bitman.com.uploadpdfsimplified;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class assgn_reg extends AppCompatActivity {

    Button register, buttonBack ;
    EditText title, descr , points, date, topic;
    String RegisterURL = "http://10.206.4.99/assign/assignment-registration.php" ;
    Boolean CheckEditText ;
    String Response;
    String titleholder, descrholder, pointsholder, dateholder, topicholder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.assign_reg);

        register = (Button)findViewById(R.id.regassign1);

      //  title = (EditText)findViewById(R.id.title1);
        descr = (EditText)findViewById(R.id.description);
        points = (EditText)findViewById(R.id.points);
        date = (EditText)findViewById(R.id.date);
        topic = (EditText)findViewById(R.id.topic);

        buttonBack = (Button) findViewById(R.id.buttonBack5);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                GetCheckEditTextIsEmptyOrNot();

                if(CheckEditText){

                    SendDataToServer(descrholder, pointsholder, dateholder, topicholder);

                }
                else {

                    Toast.makeText(assgn_reg.this, "Please fill all form fields.", Toast.LENGTH_LONG).show();

                }


            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                back();
            }
        });
    }


    public void back(){
        Intent intent = new Intent(this, display.class);
        startActivity(intent);

    }

    public void GetCheckEditTextIsEmptyOrNot(){

        titleholder = title.getText().toString();
        descrholder = descr.getText().toString();
        pointsholder = points.getText().toString();
        dateholder = date.getText().toString();
        topicholder = topic.getText().toString();

        if(TextUtils.isEmpty(titleholder) || TextUtils.isEmpty(descrholder) || TextUtils.isEmpty(pointsholder) ||  TextUtils.isEmpty(dateholder) ||  TextUtils.isEmpty(titleholder))
        {

            CheckEditText = false;

        }
        else {

            CheckEditText = true ;
        }

    }

    public void SendDataToServer(final String description1, final String points1, final String date1, final String topic1){
        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {

                //String QuickTitle = title1 ;
                String QuickDescr = description1 ;
                String QuickPoints = points1;
                String QuickDate = date1 ;
                String QuickTopic = topic1;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

               // nameValuePairs.add(new BasicNameValuePair("title", QuickTitle));
                nameValuePairs.add(new BasicNameValuePair("descr", QuickDescr));
                nameValuePairs.add(new BasicNameValuePair("points", QuickPoints));
                nameValuePairs.add(new BasicNameValuePair("date", QuickDate));
                nameValuePairs.add(new BasicNameValuePair("topic", QuickTopic));

                try {
                    HttpClient httpClient = new DefaultHttpClient();

                    HttpPost httpPost = new HttpPost(RegisterURL);

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "Data Submit Successfully";
            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                Toast.makeText(assgn_reg.this, "Data Submit Successfully", Toast.LENGTH_LONG).show();

            }
        }
        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
        sendPostReqAsyncTask.execute( description1, points1, date1, topic1);
    }

}
