package chutka.bitman.com.uploadpdfsimplified;


import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class AssignMarks extends AppCompatActivity {

    Button Markregister, back ;
    EditText name, email , password ;
    String RegisterURL = "http://10.206.4.99/assign/insertmarks.php" ;
    Boolean CheckEditText ;
    String Response;
    String NameHolder, EmailHolder, PasswordHolder ;
    String spdataholder, spdataholder1, spdataholder2;
    Spinner spdata, spdata1, spdata2;

    ArrayList<String> listItems=new ArrayList<>();
    ArrayList<String> listItems1=new ArrayList<>();
    ArrayList<String> listItems2=new ArrayList<>();
    ArrayAdapter<String> adapter;
    ArrayAdapter<String> adapter1;
    ArrayAdapter<String> adapter2;
    Spinner sp, sp1, sp2;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_marks);
        sp=(Spinner)findViewById(R.id.spinnerM);
        sp1=(Spinner)findViewById(R.id.spinnerM1);
        sp2=(Spinner)findViewById(R.id.spinnerM3);

        adapter=new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,listItems);
        sp.setAdapter(adapter);


        adapter1=new ArrayAdapter<String>(this,R.layout.spinner_layout1,R.id.txt1,listItems1);
        sp1.setAdapter(adapter1);

        adapter2=new ArrayAdapter<String>(this,R.layout.spinner_layout2,R.id.text22,listItems2);
        sp2.setAdapter(adapter2);

        Markregister = (Button)findViewById(R.id.buttonAssMarks);
        back = (Button)findViewById(R.id.buttonBack1);

        name = (EditText)findViewById(R.id.name1);
        //  email = (EditText)findViewById(R.id.email1);
        //spdata = (Spinner)findViewById(R.id.spinner);
        //  spdata1 = (Spinner)findViewById(R.id.spinner1);
        //spdata1 = (Spinner)findViewById(R.id.spinner3);




        Markregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                spdataholder = sp.getSelectedItem().toString();
                spdataholder1 = sp1.getSelectedItem().toString();
                spdataholder2 = sp2.getSelectedItem().toString();
                NameHolder = name.getText().toString();
                // EmailHolder = email.getText().toString();
                // PasswordHolder = password.getText().toString();

                SendDataToServer(spdataholder, spdataholder1, spdataholder2, NameHolder);


            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                back();

            }
        });


    }

    public void back(){
        Intent intent = new Intent(this, display.class);
        startActivity(intent);

    }



    public void onStart(){
        super.onStart();
        BackTask bt=new BackTask();
        bt.execute();

        BackTask1 bt1=new BackTask1();
        bt1.execute();

        BackTask3 bt3=new BackTask3();
        bt3.execute();
    }
    private class BackTask extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list;
        protected void onPreExecute(){
            super.onPreExecute();
            list=new ArrayList<>();
        }
        protected Void doInBackground(Void...params){
            InputStream is=null;
            String result="";
            try{
                HttpClient httpclient=new DefaultHttpClient();
                HttpPost httppost= new HttpPost("http://10.206.4.99/assign/getInterviewees.php");
                HttpResponse response=httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                // Get our response as a String.
                is = entity.getContent();
            }catch(IOException e){
                e.printStackTrace();
            }

            //convert response to string
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    result+=line;
                }
                is.close();
                //result=sb.toString();
            }catch(Exception e){
                e.printStackTrace();
            }
            // parse json data
            try{
                JSONArray jArray =new JSONArray(result);
                for(int i=0;i<jArray.length();i++){
                    JSONObject jsonObject=jArray.getJSONObject(i);
                    // add interviewee name to arraylist
                    list.add(jsonObject.getString("Student_ID"));
                }
            }
            catch(JSONException e){
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result){
            listItems.addAll(list);
            adapter.notifyDataSetChanged();
        }
    }

    private class BackTask1 extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list1;
        protected void onPreExecute(){
            super.onPreExecute();
            list1=new ArrayList<>();
        }
        protected Void doInBackground(Void...params){
            InputStream is=null;
            String result="";
            try{
                HttpClient httpclient=new DefaultHttpClient();
                HttpPost httppost= new HttpPost("http://10.206.4.99/assign/getInterviewees1.php");
                HttpResponse response=httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                // Get our response as a String.
                is = entity.getContent();
            }catch(IOException e){
                e.printStackTrace();
            }

            //convert response to string
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    result+=line;
                }
                is.close();
                //result=sb.toString();
            }catch(Exception e){
                e.printStackTrace();
            }
            // parse json data
            try{
                JSONArray jArray =new JSONArray(result);
                for(int i=0;i<jArray.length();i++){
                    JSONObject jsonObject=jArray.getJSONObject(i);
                    // add interviewee name to arraylist
                    list1.add(jsonObject.getString("Assign_ID"));
                }
            }
            catch(JSONException e){
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result){
            listItems1.addAll(list1);
            adapter1.notifyDataSetChanged();
        }
    }

    private class BackTask3 extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list2;
        protected void onPreExecute(){
            super.onPreExecute();
            list2=new ArrayList<>();
        }
        protected Void doInBackground(Void...params){
            InputStream is=null;
            String result="";
            try{
                HttpClient httpclient=new DefaultHttpClient();
                HttpPost httppost= new HttpPost("http://10.206.4.99/assign/getInterviewees4.php");
                HttpResponse response=httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                // Get our response as a String.
                is = entity.getContent();
            }catch(IOException e){
                e.printStackTrace();
            }

            //convert response to string
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    result+=line;
                }
                is.close();
                //result=sb.toString();
            }catch(Exception e){
                e.printStackTrace();
            }
            // parse json data
            try{
                JSONArray jArray =new JSONArray(result);
                for(int i=0;i<jArray.length();i++){
                    JSONObject jsonObject=jArray.getJSONObject(i);
                    // add interviewee name to arraylist
                    list2.add(jsonObject.getString("Course"));
                }
            }
            catch(JSONException e){
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result){
            listItems2.addAll(list2);
            adapter2.notifyDataSetChanged();
        }
    }



    public void SendDataToServer(final String spadata, final String name, final String email, final String password){
        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {

                String QuickSp = spadata ;
                String QuickName = name ;
                String QuickEmail = email ;
                String QuickPassword = password;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("spdata", QuickSp));
                nameValuePairs.add(new BasicNameValuePair("name", QuickName));
                nameValuePairs.add(new BasicNameValuePair("email", QuickEmail));
                nameValuePairs.add(new BasicNameValuePair("password", QuickPassword));

                try {
                    HttpClient httpClient = new DefaultHttpClient();

                    HttpPost httpPost = new HttpPost(RegisterURL);

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "Data Submit Successfully";
            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                Toast.makeText(AssignMarks.this, "Marks Submitted Successfully", Toast.LENGTH_LONG).show();

            }
        }
        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
        sendPostReqAsyncTask.execute(spadata, name, email, password);
    }

}
