package chutka.bitman.com.uploadpdfsimplified;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.UploadNotificationConfig;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button ButtonCont ;
    EditText StudentID, email , password ;
    String RegisterURL = "http://10.206.4.99/assign/insert-registration-data1.php" ;
    Boolean CheckEditText ;
    String Response;
    String StudentIDHolder, EmailHolder, PasswordHolder ;
    String spdataholder, spdataholder1, spdataholder2;
    Spinner spdata, spdata1;

    //ArrayList<String> listItems=new ArrayList<>();
    ArrayList<String> listItems1=new ArrayList<>();
    ArrayList<String> listItems2=new ArrayList<>();
    ArrayAdapter<String> adapter;
    ArrayAdapter<String> adapter1;
    ArrayAdapter<String> adapter2;
    Spinner sp, sp1, sp2;
    //Declaring views
    private Button buttonChoose;
    private Button buttonUpload;

    private EditText editText, editTextMark;

    public static final String UPLOAD_URL = "http://10.206.4.99/assign/upload.php";
    public static final String PDF_FETCH_URL = "http://10.206.4.99/assign/getPdfs.php";

    ImageView imageView;

    //Image request code
    private int PICK_PDF_REQUEST = 1;

    //storage permission code
    private static final int STORAGE_PERMISSION_CODE = 123;



    //Uri to store the image uri
    private Uri filePath;

    //ListView to show the fetched Pdfs from the server
    ListView listView;

    //button to fetch the intiate the fetching of pdfs.
    Button buttonFetch;

    //Progress bar to check the progress of obtaining pdfs
    ProgressDialog progressDialog;

    //an array to hold the different pdf objects
    ArrayList<Pdf> pdfList= new ArrayList<Pdf>();

    //pdf adapter

    PdfAdapter pdfAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Requesting storage permission
        requestStoragePermission();

        //Initializing views
        buttonChoose = (Button) findViewById(R.id.buttonChoose);
        buttonUpload = (Button) findViewById(R.id.buttonUpload);

        editText = (EditText) findViewById(R.id.editTextName);
        //editTextMark = (EditText) findViewById(R.id.editTextMarking);

       //// editTextMark.setEnabled(false);


        //initializing ListView
       // listView = (ListView) findViewById(R.id.listView);

        //initializing buttonFetch
      //  buttonFetch = (Button) findViewById(R.id.buttonFetchPdf1);

        //initializing progressDialog

        sp1=(Spinner)findViewById(R.id.spinner22);
        sp2=(Spinner)findViewById(R.id.spinner33);

        //  adapter=new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,listItems);
        // sp.setAdapter(adapter);


        adapter1=new ArrayAdapter<String>(this,R.layout.spinner_layout1,R.id.txt1,listItems1);
        sp1.setAdapter(adapter1);

        adapter2=new ArrayAdapter<String>(this,R.layout.spinner_layout2,R.id.text22,listItems2);
        sp2.setAdapter(adapter2);

        progressDialog = new ProgressDialog(this);

        //Setting clicklistener
        buttonChoose.setOnClickListener(this);
        buttonUpload.setOnClickListener(this);
      //  buttonFetch.setOnClickListener(this);


      //  ButtonCont.setOnClickListener(new View.OnClickListener() {
            //@Override
         //   public void onClick(View view) {

                // spdataholder = sp.getSelectedItem().toString();
              //  spdataholder1 = sp1.getSelectedItem().toString();
             //   spdataholder2 = sp2.getSelectedItem().toString();
            //    StudentIDHolder = StudentID.getText().toString();
                // PasswordHolder = password.getText().toString();

                   // String name = editText.getText().toString().trim();

        //getting the actual path of the pdf
       // String path = FilePath.getPath(this, filePath);

             //   SendDataToServer(StudentIDHolder, spdataholder1, spdataholder2 );


                //Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                // startActivity(intent);
              //  admin1();
        //    }
    //    });






    }



    /*
     * This is the method responsible for pdf upload
     * We need the full pdf path and the name for the pdf in this method
     * */



    public void uploadMultipart() {


        //int myNum = 0;
      //  myNum = Integer.parseInt(sp2.getSelectedItem().toString());
      //  String numberAsString = Integer.toString(myNum);

         spdataholder1 = sp1.getSelectedItem().toString();
           spdataholder2 = sp2.getSelectedItem().toString();
         //  StudentIDHolder = StudentID.getText().toString();


        //String name = editText.getText().toString().trim();

        //getting the actual path of the pdf
        // String path = FilePath.getPath(this, filePath);



        //getting name for the pdf
        String name = editText.getText().toString().trim();

        //getting the actual path of the pdf
        String path = FilePath.getPath(this, filePath);

       // SendDataToServer(name, path, spdataholder1, spdataholder2);

        if (path == null) {

            Toast.makeText(this, "Please move your .pdf file to internal storage and retry", Toast.LENGTH_LONG).show();
        } else {
            //Uploading code
            try {
                String uploadId = UUID.randomUUID().toString();

                //Creating a multi part request
                new MultipartUploadRequest(this, uploadId, UPLOAD_URL)
                        .addFileToUpload(path, "pdf") //Adding file
                        .addParameter("name", name) //Adding text parameter to the request
                        .addParameter("id", spdataholder1) //Adding text parameter to the request
                        .addParameter("course", spdataholder2) //Adding text parameter to the request
                        .setNotificationConfig(new UploadNotificationConfig())
                        .setMaxRetries(2)
                        .startUpload(); //Starting the upload

            } catch (Exception exc) {
                Toast.makeText(this, exc.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }


    //method to show file chooser
    private void showFileChooser() {
        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_PDF_REQUEST);
    }

    //handling the ima chooser activity result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();

        }
    }


    //Requesting permission
    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }


    //This method will be called when the user will tap on allow or deny
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if (requestCode == STORAGE_PERMISSION_CODE) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Displaying a toast
                Toast.makeText(this, "Permission granted now you can read the storage", Toast.LENGTH_LONG).show();
            } else {
                //Displaying another toast if permission is not granted
                Toast.makeText(this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }


    public void exit(View v) {
        Intent intent = new Intent(MainActivity.this, dashboard.class);
        finish();
        startActivity(intent);
    }


    @Override
    public void onClick(View v) {
        if (v == buttonChoose) {
            showFileChooser();
        }
        if (v == buttonUpload) {
            uploadMultipart();
        }


    }


    public void onStart(){
        super.onStart();
        // BackTask bt=new BackTask();
        // bt.execute();

        BackTask1 bt1=new BackTask1();
        bt1.execute();

        BackTask2 bt2=new BackTask2();
        bt2.execute();
    }


    private class BackTask1 extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list1;
        protected void onPreExecute(){
            super.onPreExecute();
            list1=new ArrayList<>();
        }
        protected Void doInBackground(Void...params){
            InputStream is=null;
            String result="";
            try{
                HttpClient httpclient=new DefaultHttpClient();
                HttpPost httppost= new HttpPost("http://10.206.4.99/assign/getInterviewees1.php");
                HttpResponse response=httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                // Get our response as a String.
                is = entity.getContent();
            }catch(IOException e){
                e.printStackTrace();
            }

            //convert response to string
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    result+=line;
                }
                is.close();
                //result=sb.toString();
            }catch(Exception e){
                e.printStackTrace();
            }
            // parse json data
            try{
                JSONArray jArray =new JSONArray(result);
                for(int i=0;i<jArray.length();i++){
                    JSONObject jsonObject=jArray.getJSONObject(i);
                    // add interviewee name to arraylist
                    list1.add(jsonObject.getString("Assign_ID"));
                }
            }
            catch(JSONException e){
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result){
            listItems1.addAll(list1);
            adapter1.notifyDataSetChanged();
        }
    }



    private class BackTask2 extends AsyncTask<Void,Void,Void> {
        ArrayList<String> list2;
        protected void onPreExecute(){
            super.onPreExecute();
            list2=new ArrayList<>();
        }
        protected Void doInBackground(Void...params){
            InputStream is=null;
            String result="";
            try{
                HttpClient httpclient=new DefaultHttpClient();
                HttpPost httppost= new HttpPost("http://10.206.4.99/assign/getInterviewees2.php");
                HttpResponse response=httpclient.execute(httppost);
                HttpEntity entity = response.getEntity();
                // Get our response as a String.
                is = entity.getContent();
            }catch(IOException e){
                e.printStackTrace();
            }

            //convert response to string
            try{
                BufferedReader reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    result+=line;
                }
                is.close();
                //result=sb.toString();
            }catch(Exception e){
                e.printStackTrace();
            }
            // parse json data
            try{
                JSONArray jArray =new JSONArray(result);
                for(int i=0;i<jArray.length();i++){
                    JSONObject jsonObject=jArray.getJSONObject(i);
                    // add interviewee name to arraylist
                    list2.add(jsonObject.getString("Course"));
                }
            }
            catch(JSONException e){
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result){
            listItems2.addAll(list2);
            adapter2.notifyDataSetChanged();
        }
    }


    public void SendDataToServer(final String spadata, final String name, final String email, final String path){
        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {

                String QuickName = name ;
                String QuickPath = path;
                String QuickSp = spadata ;

                String QuickEmail = email ;


                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("name", QuickName));
                nameValuePairs.add(new BasicNameValuePair("path", QuickPath));
                nameValuePairs.add(new BasicNameValuePair("spdata", QuickSp));

                nameValuePairs.add(new BasicNameValuePair("email", QuickEmail));


                try {
                    HttpClient httpClient = new DefaultHttpClient();

                    HttpPost httpPost = new HttpPost(RegisterURL);

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpClient.execute(httpPost);

                    HttpEntity entity = response.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "Data Submit Successfully";
            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                Toast.makeText(MainActivity.this, "Marks Submitted Successfully", Toast.LENGTH_LONG).show();



            }
        }
        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();
        sendPostReqAsyncTask.execute(name, path, spadata, email);
    }



}